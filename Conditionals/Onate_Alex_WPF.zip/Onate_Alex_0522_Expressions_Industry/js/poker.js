//Ternary Operators

var player = 5;
var pokerGame;

//if the player has a 8 or better he wins, otherwise he losses the game
pokerGame = (player < 8) ? "He Wins" : "He Losses";
console.log(pokerGame);
